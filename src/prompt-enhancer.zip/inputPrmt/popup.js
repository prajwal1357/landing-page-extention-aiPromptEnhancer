document.addEventListener("DOMContentLoaded", () => {
  const apiKeyInput = document.getElementById("apiKey");
  const saveBtn = document.getElementById("save");
  const statusMsg = document.getElementById("statusMessage");

  // Load existing key
  chrome.storage.local.get("geminiKey", (data) => {
    if (data.geminiKey) {
      apiKeyInput.value = data.geminiKey;
    }
  });

  saveBtn.addEventListener("click", () => {
    const key = apiKeyInput.value.trim();

    if (!key) {
      showStatus("Please enter an API key", false);
      return;
    }

    chrome.storage.local.set({ geminiKey: key }, () => {
      showStatus("Settings saved successfully!", true);
    });
  });

  function showStatus(text, isSuccess) {
    statusMsg.querySelector("span").textContent = text;
    statusMsg.className = `status show ${isSuccess ? "success" : ""}`;
    statusMsg.style.color = isSuccess ? "var(--success)" : "#ef4444";
    
    statusMsg.querySelector("svg").style.display = isSuccess ? "block" : "none";

    setTimeout(() => {
      statusMsg.classList.remove("show");
    }, 2500);
  }
});