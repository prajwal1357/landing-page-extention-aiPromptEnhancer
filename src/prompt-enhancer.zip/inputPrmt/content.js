console.log("content script loaded");

function getInputBox() {
  // Priority 1: Check for contenteditable (ChatGPT/Claude/Gemini)
  let el = document.querySelector('[contenteditable="true"]');
  if (el) return el;

  // Priority 2: Standard textareas
  return document.querySelector("textarea");
}

function getPrompt(input) {
  return input.tagName === "TEXTAREA" ? input.value : input.innerText;
}

function setPrompt(input, text) {
  if (input.tagName === "TEXTAREA") {
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
    nativeSetter.call(input, text);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  } else {
    // For ContentEditable (ChatGPT/Claude)
    input.focus();
    document.execCommand('selectAll', false, null);
    document.execCommand('insertText', false, text);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }
}

function injectButton() {
  const input = getInputBox();
  if (!input || document.getElementById("enhance-btn")) return;

  const btn = document.createElement("button");
  btn.innerText = "✨ Enhance";
  btn.id = "enhance-btn";

  // Modern Styling
  Object.assign(btn.style, {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "6px",
    margin: " 8px 5px",
    padding: "8px 18px",
    borderRadius: "20px",
    border: "1px solid rgba(255, 255, 255, 0.1)",
    background: "linear-gradient(135deg, rgba(59, 130, 246, 0.95), rgba(139, 92, 246, 0.95))",
    backdropFilter: "blur(10px)",
    color: "#ffffff",
    cursor: "pointer",
    fontWeight: "600",
    fontSize: "14px",
    fontFamily: "'Inter', -apple-system, sans-serif",
    zIndex: "9999",
    boxShadow: "0 4px 15px rgba(59, 130, 246, 0.3)",
    transition: "all 0.3s ease",
    textShadow: "0 1px 2px rgba(0,0,0,0.1)"
  });

  btn.onmouseover = () => {
    btn.style.transform = "translateY(-2px)";
    btn.style.boxShadow = "0 6px 20px rgba(139, 92, 246, 0.4)";
    btn.style.background = "linear-gradient(135deg, rgba(59, 130, 246, 1), rgba(139, 92, 246, 1))";
  };
  
  btn.onmouseout = () => {
    btn.style.transform = "translateY(0)";
    btn.style.boxShadow = "0 4px 15px rgba(59, 130, 246, 0.3)";
    btn.style.background = "linear-gradient(135deg, rgba(59, 130, 246, 0.95), rgba(139, 92, 246, 0.95))";
  };

  // Position: Directly above the input box
  input.parentNode.insertBefore(btn, input);

  btn.onclick = async (e) => {
    e.preventDefault();
    const original = getPrompt(input);

    if (!original.trim()) {
      alert("Type something first");
      return;
    }

    const { geminiKey } = await chrome.storage.local.get("geminiKey");

    if (!geminiKey) {
      alert("Please add your Gemini API key in the extension popup");
      return;
    }

    const originalText = btn.innerText;
    btn.innerText = "✨ Enhancing...";
    btn.disabled = true;

    try {
      // Model URL
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${geminiKey}`;
      
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ 
            parts: [{ 
              text: `Act as an expert prompt engineer. Improve and Make the prompt Detailed for better AI results. 
              Return ONLY the improved prompt text. 
              IMPORTANT: Do not use any markdown formatting (like **bolding**). 
              Do not use forward slashes (/) in your response. 
              The response must be plain text only.\n\n${original}` 
            }] 
          }]
        })
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error?.message || `API error: ${res.status}`);
      }

      const data = await res.json();
      const enhanced = data.candidates?.[0]?.content?.parts?.[0]?.text;

      if (!enhanced) throw new Error("No response from Gemini");

      // Final cleanup just in case the AI ignores instructions
      const cleanedText = enhanced.replace(/\*\*/g, '').replace(/\//g, '').trim();

      setPrompt(input, cleanedText);
    } catch (err) {
      console.error(err);
      alert("Enhancement failed: " + err.message);
    } finally {
      btn.innerText = originalText;
      btn.disabled = false;
    }
  };
}

// Check more frequently initially, then settle down
setInterval(injectButton, 1000);